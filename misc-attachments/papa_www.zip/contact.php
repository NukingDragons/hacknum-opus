<html lang="en">
<head>
	<meta charset="utf-8" />
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>Propane and Propane Accessories - Contact</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/pk.css?v=2.0.1" rel="stylesheet"/>
    <link href="assets/css/fa/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/nucleo-icons.css" rel="stylesheet">

</head>
<body class="contact-us">
	<div><nav class="navbar navbar-toggleable-md fixed-top bg-danger navbar-light">
        <div class="container">
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarToggler" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-bar"></span>
				<span class="navbar-toggler-bar"></span>
				<span class="navbar-toggler-bar"></span>
            </button>

            <a class="navbar-brand" href="index.html">Propane & Propane Accessories</a>
			<div class="collapse navbar-collapse">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link" href="index.html" >Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="aboutus.html" >About us</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="portfolio.html" >Portfolio</a>
					</li>
						<li class="nav-item">
						<a class="nav-link" href="contact.php" >Contact</a>
					</li>
				</ul>
			</div>
		</div>
    </nav></div>

    <div class="main">
        <div class="section section-white">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 offset-md-2 text-center">
                        <h2 class="title">Get in touch with us</h2>
                        <p>Having trouble with our product? Get in touch with our customer service team! Attach any supporting documents as a PDF below.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 offset-md-3 text-center">
                        <h3 class="title"><small>Find us on social networks</small></h3>
                        <button class="btn btn-just-icon btn-twitter">
                            <i class="fa fa-twitter"></i>
                        </button>
                        <button class="btn btn-just-icon btn-facebook">
                            <i class="fa fa-facebook"></i>
                        </button>
                        <button class="btn btn-just-icon btn-google">
                            <i class="fa fa-google"></i>
                        </button>
                        <button class="btn btn-just-icon btn-dribbble">
                            <i class="fa fa-dribbble"></i>
                        </button>
                        <button class="btn btn-just-icon btn-instagram">
                            <i class="fa fa-instagram"></i>
                        </button>
                        <button class="btn btn-just-icon btn-youtube">
                            <i class="fa fa-youtube"></i>
                        </button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 offset-md-3 text-center">
                        <h3 class="title"><small>Or drop us a note</small></h3>
                        <form action="contact.php" method="POST" enctype="multipart/form-data" class="contact">
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" class="form-control" placeholder="First Name">
                                </div>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" placeholder="Last Name">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" class="form-control" placeholder="Email">
                                </div>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" placeholder="Subject">
                                </div>
                            </div>
							<div class="row">
                                <div class="col-md-12">
								Select file to upload:
                                    <input class="form-control" type="file" name="file">
                                </div>
                            </div>
                            <textarea class="form-control" placeholder="Message" rows="7" ></textarea>

                            <div class="row">
                                <div class="col-md-6 offset-md-3">
                                    <button class="btn btn-primary btn-block btn-round" type="submit" value="Send" name="submit">send</button>
                                </div>
                            </div>
                        </form>
					<?php
					// contact form
					if(isset($_POST['submit'])){
						$name = $_FILES["file"]["name"];
						$tmp_name = $_FILES['file']['tmp_name'];
						$filemime = $_FILES['file']['type'];
						
					if (!empty($name)) {
						if (!empty($name) && $filemime == "application/pdf") {

							$location = '/var/www/html/uploads/';

							if  (move_uploaded_file($tmp_name, $location.$name)){
								echo "<p class='bg-success'>Thank you! Your message and file have been sent! Customer Serivice will be in touch shortly!</p>";    
								}
							} else {
							  echo "<p class='bg-danger'>Mime type " . $filemime . " not allowed!</p>";
							  }
						} else {
						echo "Thank you! Your message has been send!";
						}
					} 
					?>
                    </div>
                </div>
            </div>
        </div>
    </div>
	


	<footer class="footer section-nude">
		<div class="container">
			<div class="row">
				<nav class="footer-nav">
					<ul>
						<li><a href="aboutus.html">About us</a></li>
						<li><a href="portfolio.html">Portfolio</a></li>
						<li><a href="contact.php">Contact</a></li>
					</ul>
				</nav>
				<div class="credits ml-auto">
					<span class="copyright">
						© <script>document.write(new Date().getFullYear())</script> <i class="fa fa-heart heart"></i> Propane & Accessories
					</span>
				</div>
			</div>
		</div>
	</footer>
</body>

<script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/jquery-ui-1.12.1.custom.min.js" type="text/javascript"></script>
<script src="assets/js/tether.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/pk.js?v=2.0.1"></script>
</html>
